﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameControl : MonoBehaviour
{
    public static GameControl instance;
    public float scrollSpeed = -15f;

    public Text scoreText;
    public GameObject gameOverText;
    public bool gameOver = false;

    private int score;


    // Start is called before the first frame update
    void Awake()
    {
        if(instance==null)
        {
            instance = this;
        }
        if(instance!=this)
        {
            Destroy(gameObject);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(gameOver==true && Input.GetKey("w"))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }

    public void BirdScored()
    {
        if(gameOver)
        {
            return;
        }
        score++;

        scoreText.text = "Score: " + score.ToString(); 
    }


    public void BirdDied()
    {
        gameOverText.SetActive(true);
        gameOver = true;
    }
}
